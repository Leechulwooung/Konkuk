//sub node

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Header.h>
#include <geometry_msgs/Pose.h>
//#include <time.h>
#include <iostream>
#include <std_msgs/Int32.h>
#include <std_msgs/Bool.h>

class My_waypoint{
  protected:
    ros::NodeHandle g_nh;
    ros::Subscriber website_sub = g_nh.subscribe<std_msgs::Int32>("website_topic",100, &My_waypoint::website_callback, this);
    ros::Subscriber call_sub = g_nh.subscribe<std_msgs::Int32>("call_topic",100, &My_waypoint::call_callback, this);

    ros::Publisher goal_publisher = g_nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 100);
    
    int website_answer = 0;
    int call_answer = 0;
    bool answer_toggle = false;

  public:
    My_waypoint();
    ~My_waypoint();
    void website_callback(const std_msgs::Int32ConstPtr& msg);
    void call_callback(const std_msgs::Int32ConstPtr& msg);
    void goal_select();
    void call_goal_select();

    // 한 번만 돌게 하기 위해서 추가한 토글 변수
    bool loop_only_once_website_toggle = false;
    bool loop_only_once_call_toggle = false;
};

My_waypoint::My_waypoint(){}

My_waypoint::~My_waypoint(){}

void My_waypoint::website_callback(const std_msgs::Int32ConstPtr& msg){
  website_answer = msg->data;
  answer_toggle = true;

  // 토픽이 들어오면 토글 true
  loop_only_once_website_toggle = true;
}

void My_waypoint::call_callback(const std_msgs::Int32ConstPtr& msg){
  call_answer = msg->data;
  answer_toggle = true;

  // 토픽이 들어오면 토글 true
  loop_only_once_call_toggle = true;
}

// 배송 보낼 거점 설정
void My_waypoint::goal_select(){

  geometry_msgs::PoseStamped pose_stamped;
  /*
  // 전역 변수로 변경
  geometry_msgs::PoseStamped pose_stamped_A;
  geometry_msgs::PoseStamped pose_stamped_B;
  geometry_msgs::PoseStamped pose_stamped_C;
  geometry_msgs::PoseStamped pose_stamped_D;
  */
  
  if(answer_toggle = true){
    //if(website_answer == 1 || website_answer ==5){
    if(website_answer == 1 || website_answer == 5){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = -2.3726302345039585e-07;
      pose_stamped.pose.position.y = -1.9903066158294678;
      pose_stamped.pose.orientation.z = 0.01561849853981587;
      pose_stamped.pose.orientation.w = 0.9998780238125857;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(website_answer == 2 || website_answer == 6){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = 1.9903068542480469;
      pose_stamped.pose.position.y = 0.0074262963607907295;
      pose_stamped.pose.orientation.z = 0.9999999999999971;
      pose_stamped.pose.orientation.w = 7.549789954891874e-08;
    
      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(website_answer == 3 || website_answer == 7){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = 2.390336817370553e-07;
      pose_stamped.pose.position.y = 2.005160093307495;
      pose_stamped.pose.orientation.z = 0.7071067544940086;
      pose_stamped.pose.orientation.w = 0.7071068078790854;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(website_answer == 4 || website_answer == 8){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = -2.005159854888916;
      pose_stamped.pose.position.y = 0.007426772732287645;
      pose_stamped.pose.orientation.z = -0.7071067966408575;
      pose_stamped.pose.orientation.w = 0.7071067657322372;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    
    goal_publisher.publish(pose_stamped);
    answer_toggle = false;

  }
}

///////////////////////// 호출할 때 위치 설정/////////////////////////////////
void My_waypoint::call_goal_select(){

  geometry_msgs::PoseStamped pose_stamped;

  if(answer_toggle = true){
    if(call_answer == 1){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = -2.3726302345039585e-07;
      pose_stamped.pose.position.y = -1.9903066158294678;
      pose_stamped.pose.orientation.z = 0.01561849853981587;
      pose_stamped.pose.orientation.w = 0.9998780238125857;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(call_answer == 2){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = 1.9903068542480469;
      pose_stamped.pose.position.y = 0.0074262963607907295;
      pose_stamped.pose.orientation.z = 0.9999999999999971;
      pose_stamped.pose.orientation.w = 7.549789954891874e-08;
    
      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(call_answer == 3){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = 2.390336817370553e-07;
      pose_stamped.pose.position.y = 2.005160093307495;
      pose_stamped.pose.orientation.z = 0.7071067544940086;
      pose_stamped.pose.orientation.w = 0.7071068078790854;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    else if(call_answer == 4){

      //pose_stamped.header.stamp = ros::Time::now();
      pose_stamped.header.frame_id = "map";
      pose_stamped.pose.position.x = -2.005159854888916;
      pose_stamped.pose.position.y = 0.007426772732287645;
      pose_stamped.pose.orientation.z = -0.7071067966408575;
      pose_stamped.pose.orientation.w = 0.7071067657322372;

      // Print the pose information to the terminal
      ROS_INFO("Goal pose:");
      ROS_INFO("  Position: x = %f, y = %f", pose_stamped.pose.position.x, pose_stamped.pose.position.y);
      ROS_INFO("  Orientation: z = %f, w = %f", pose_stamped.pose.orientation.z, pose_stamped.pose.orientation.w);

    }
    
    goal_publisher.publish(pose_stamped);
    answer_toggle = false;

  }
}
/////////////////////////////////////////////////////////////////////

/*
void 초기 등록 거점 과 경유지에서 등록 거점 비교 함수(){
  
}
*/

int main(int argc, char** argv) {
  ros::init(argc, argv, "goal_node");

  My_waypoint my_waypoint; 

  ros::Rate loop_rate(10);

  while(ros::ok()){

    // 한 번만 돌게 하기 위해서 toggle 조건 판단

    // website에서 배송 보낼 거점 결정
    if(my_waypoint.loop_only_once_website_toggle){
      my_waypoint.goal_select();
      my_waypoint.loop_only_once_website_toggle = false; // goal_select() 함수를 한 번 수행했으므로 토글 false
    }

    // 호출할 거점 정보
    if(my_waypoint.loop_only_once_call_toggle){
      my_waypoint.call_goal_select();
      my_waypoint.loop_only_once_call_toggle = false; // goal_select() 함수를 한 번 수행했으므로 토글 false
    }

    ros::spinOnce();
    loop_rate.sleep();
  }

  return 0;
}